package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.MathHelper;

/**
 * Spin Bot: gửi góc nhìn xoay tròn lên server (người khác thấy nhân vật xoay), camera của bạn đứng yên.
 * Mặc định ĐANG ĐI THÌ KHÔNG XOAY (nhiều server/anti-cheat tính hướng đi theo góc nhìn nên xoay lúc đi sẽ bị giật/đứng yên).
 * Nhân vật của bạn cũng xoay thật trên màn hình (nhìn ở ngôi 3).
 */
public class SpinBot {
    static float yaw, phase;
    static boolean was;

    static void restore(MinecraftClient mc) {
        var p = mc.player;
        if (p != null && p.networkHandler != null) Util.sendLook(p.getYaw(), p.getPitch());
        was = false;
    }

    static boolean moving(MinecraftClient mc) {
        var o = mc.options;
        return o.forwardKey.isPressed() || o.backKey.isPressed() || o.leftKey.isPressed() || o.rightKey.isPressed() || o.jumpKey.isPressed() || o.sneakKey.isPressed();
    }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player;
        if (!c.spinOn || !c.enabled || p == null || mc.world == null || p.networkHandler == null) { if (was) restore(mc); return; }
        if (p.isGliding() || (c.spinPause && p.isUsingItem())) { if (was) restore(mc); return; }
        if (!c.spinMoving && moving(mc)) { if (was) restore(mc); return; }       // đang đi: để góc thật, đi bình thường
        if (!was) { yaw = p.getYaw(); phase = 0; }
        float step = (c.spinDir == 0 ? 1 : -1) * (float) c.spinSpeed;
        yaw = MathHelper.wrapDegrees(yaw + step);
        phase += 0.35f;
        float pitch = switch (c.spinPitch) {
            case 1 -> 90f;
            case 2 -> 60f * (float) Math.sin(phase);
            default -> p.getPitch();
        };
        Util.sendLook(yaw, pitch);
        if (c.spinVisual) {                                   // xoay mô hình nhân vật của chính bạn
            p.prevBodyYaw = MathHelper.wrapDegrees(yaw - step); p.bodyYaw = yaw;
            p.prevHeadYaw = MathHelper.wrapDegrees(yaw - step); p.headYaw = yaw;
        }
        was = true;
    }
}
