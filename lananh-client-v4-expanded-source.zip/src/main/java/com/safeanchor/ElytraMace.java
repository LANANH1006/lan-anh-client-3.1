package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/**
 * Elytra + Mace tự động.
 * Bình thường: cất cánh -> bay lên cao hơn đối thủ -> (cánh -> áo, vì mace chỉ smash khi KHÔNG bay) -> rơi xuống đập.
 * Chuỗi đập: vừa đập xong bị hất lên nhẹ -> KHÔNG bay lên cao nữa, dùng cánh lao thẳng xuống đối thủ rồi đập tiếp.
 */
public class ElytraMace {
    static boolean diving, keysHeld, quick, hitFlag;
    static int stage;   // 0 = còn đeo cánh, bay tới gần đối thủ; 1 = đã đổi áo, rơi đập
    static int cd, rocketCd, axeCd;
    public static int chain;   // số tick còn lại của "chuỗi đập"

    public static void toggle(MinecraftClient mc) {
        Config.I.autoMace = !Config.I.autoMace;
        if (!Config.I.autoMace) release(mc);
        Util.msg("Elytra Mace: " + (Config.I.autoMace ? "§aBẬT" : "§cTẮT"));
        Config.save();
    }

    /** Gọi mỗi khi đập đối thủ bằng mace (tự đập hoặc bạn tự bấm). */
    public static void onHit() {
        if (!Config.I.autoMace) return;
        if (Config.I.maceChain) chain = 45;
        hitFlag = true;
    }

    static void release(MinecraftClient mc) {
        if (keysHeld) { mc.options.forwardKey.setPressed(false); mc.options.jumpKey.setPressed(false); keysHeld = false; }
        diving = false; stage = 0; quick = false; hitFlag = false;
    }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I;
        var p = mc.player;
        if (!c.autoMace || !c.enabled || p == null || mc.world == null || mc.interactionManager == null) { if (keysHeld) release(mc); return; }
        if (p.isSpectator() || p.isDead()) return;
        if (cd > 0) cd--;
        if (rocketCd > 0) rocketCd--;
        if (axeCd > 0) axeCd--;
        if (chain > 0) chain--;

        PlayerEntity t = Util.nearestEnemy(c.maceRange);
        if (t == null) { release(mc); return; }

        if (p.getHealth() + p.getAbsorptionAmount() < c.minSelfHealth) {
            release(mc);
            if (c.maceSwapChest && cd == 0 && Util.chestIs(Util::isElytra)) { Util.equipChest(Util::isChestplate, true); cd = 5; }
            Util.warn("Máu thấp - Elytra Mace tạm dừng");
            return;
        }

        switch (c.maceView) {
            case 1 -> mc.options.setPerspective(Perspective.FIRST_PERSON);
            case 2 -> mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
            case 3 -> mc.options.setPerspective(Perspective.THIRD_PERSON_FRONT);
            default -> {}
        }

        double above = p.getY() - t.getY();
        double horiz = Math.hypot(p.getX() - t.getX(), p.getZ() - t.getZ());
        double dist = Util.distToBox(p.getEyePos(), t.getBoundingBox());

        if (diving) { dive(mc, t, dist); return; }
        hitFlag = false;

        // ===== CHUỖI ĐẬP: vừa đập, đang bị hất lên nhẹ -> đeo cánh rồi lao xuống đập tiếp =====
        if (c.maceChain && chain > 0 && !p.isOnGround() && horiz <= c.maceHorizDive) {
            if (cd > 0) return;
            if (!Util.chestIs(Util::isElytra)) { if (Util.equipChest(Util::isElytra, false)) cd = 2; return; }
            diving = true; stage = 0; quick = true; cd = 0;
            return;
        }

        // ===== GIAI ĐOẠN BAY LÊN =====
        if (cd > 0) return;
        if (!Util.chestIs(Util::isElytra)) {
            if (Util.equipChest(Util::isElytra, false)) { cd = 3; } else { Util.warn("Không có elytra trong túi!"); }
            return;
        }
        if (p.isOnGround()) {                       // cất cánh
            mc.options.jumpKey.setPressed(true); keysHeld = true; return;
        }
        mc.options.jumpKey.setPressed(false);
        if (!p.isGliding()) {                       // bắt đầu bay giữa không trung
            if (p.getVelocity().y < 0) {
                p.networkHandler.sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
                p.startGliding();
            }
            return;
        }
        Vec3d aim = new Vec3d(t.getX(), t.getY() + c.maceDiveDist + 8, t.getZ());
        Util.aim(p, aim);
        if (c.maceUseRocket && rocketCd == 0 && p.getVelocity().length() < 1.1 && Util.selectItem(s -> s.isOf(Items.FIREWORK_ROCKET))) {
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            rocketCd = 14;
        }
        if (above >= c.maceDiveDist && horiz <= c.maceHorizDive) { diving = true; stage = 0; quick = false; cd = 0; }
    }

    /** Bỏ lượt / đập xong: đeo lại cánh (cd ngắn) và làm vòng mới. */
    private static void abort(MinecraftClient mc) { release(mc); cd = 1; }

    private static void dive(MinecraftClient mc, PlayerEntity t, double dist) {
        Config c = Config.I; var p = mc.player;
        double horiz = Math.hypot(p.getX() - t.getX(), p.getZ() - t.getZ());
        double above = p.getY() - t.getY();
        if (!t.isAlive()) { abort(mc); return; }

        // ===== GIAI ĐOẠN 0: vẫn đeo cánh, bay (lao) tới sát đối thủ =====
        if (stage == 0) {
            if (!Util.chestIs(Util::isElytra)) {
                if (cd == 0 && Util.equipChest(Util::isElytra, false)) cd = 3;
                return;
            }
            if (!p.isGliding()) {
                if (p.isOnGround()) { abort(mc); return; }
                if (p.getVelocity().y < 0) {        // đợi hết đà bị hất lên rồi mới mở cánh
                    p.networkHandler.sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
                    p.startGliding();
                }
                return;
            }
            if (horiz > c.maceHorizDive + 10 || above < (quick ? -1.0 : 2.0)) { abort(mc); return; }   // đối thủ chạy/pearl đi chỗ khác
            Util.aim(p, t.getPos().add(0, t.getHeight() * 0.5, 0));
            if (c.maceUseRocket && rocketCd == 0 && p.getVelocity().length() < 1.1 && Util.selectItem(s -> s.isOf(Items.FIREWORK_ROCKET))) {
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                rocketCd = 14;
            }
            double swap = quick ? c.maceChainSwap : c.maceSwapDist;
            if (dist <= swap && above > (quick ? 0.5 : 3.0)) { stage = 1; cd = 0; }
            return;
        }

        // ===== GIAI ĐOẠN 1: đổi sang áo (hết bay), rơi xuống đập =====
        if (hitFlag) { hitFlag = false; abort(mc); return; }                            // bạn vừa tự đập xong -> làm vòng mới
        if (horiz > c.maceAbortDist || above < (quick ? -0.5 : 0)) { abort(mc); return; }
        if (c.maceSwapChest && (p.isGliding() || Util.chestIs(Util::isElytra))) {
            if (cd == 0) { Util.equipChest(Util::isChestplate, true); cd = 2; }
            if (p.isGliding()) p.stopGliding();
            return;
        }
        // đối thủ đang giơ khiên chặn -> đổi rìu đập phá khiên trước
        if (c.maceAxe && c.maceAutoHit && t.isBlocking() && dist <= c.maceHitDist && Util.has(s -> s.isIn(ItemTags.AXES))) {
            Util.selectItem(s -> s.isIn(ItemTags.AXES));
            Util.aim(p, t.getPos().add(0, t.getHeight() * 0.5, 0));
            mc.options.forwardKey.setPressed(true); keysHeld = true;
            if (axeCd == 0 && p.getAttackCooldownProgress(0.5f) >= 0.9f) {
                mc.interactionManager.attackEntity(p, t);
                p.swingHand(Hand.MAIN_HAND);
                axeCd = 12;
            }
            return;
        }
        if (!Util.selectItem(s -> s.isOf(Items.MACE))) { Util.warn("Không có mace!"); release(mc); return; }
        Util.aim(p, t.getPos().add(0, t.getHeight() * 0.5, 0));
        mc.options.forwardKey.setPressed(true); keysHeld = true;

        boolean heightReady = !c.maceHeightGate || Math.abs(p.getY() - (t.getY() + t.getHeight())) <= 0.35;
        if (c.maceAutoHit && heightReady && dist <= c.maceHitDist && p.getAttackCooldownProgress(0.5f) >= 0.9f) {
            mc.interactionManager.attackEntity(p, t);
            p.swingHand(Hand.MAIN_HAND);
            if (c.maceChain) chain = 45;
            abort(mc);          // đập xong: đeo cánh lại, bị hất nhẹ thì lao xuống đập tiếp
        }
    }
}
