package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

/** Triggerbot: đánh ngay khi tâm ngắm đang trúng người và cooldown đã đầy. */
public class Combat2 {
    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player;
        if (!c.trigOn || !c.enabled || p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (mc.crosshairTarget instanceof EntityHitResult eh && eh.getEntity() instanceof PlayerEntity t && t != p && !t.isSpectator()
                && p.getAttackCooldownProgress(0.5f) >= 0.95f) {
            mc.interactionManager.attackEntity(p, t);
            p.swingHand(Hand.MAIN_HAND);
        }
    }
}
