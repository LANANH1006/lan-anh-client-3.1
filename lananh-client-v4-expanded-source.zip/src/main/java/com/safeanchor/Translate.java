package com.safeanchor;

import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Pattern;

/** Dịch chat: tin nhắn tiếng Anh nhận được -> thêm dòng tiếng Việt; tin bạn gõ có dấu tiếng Việt -> gửi bản tiếng Anh. */
public class Translate {
    static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(4)).build();
    static final Pattern VI = Pattern.compile("[àáạảãăằắặẳẵâầấậẩẫđèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹ]", Pattern.CASE_INSENSITIVE);
    static boolean bypass;

    static CompletableFuture<String> translate(String text, String to) {
        String url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=" + to + "&dt=t&q=" + URLEncoder.encode(text, StandardCharsets.UTF_8);
        HttpRequest rq = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(5)).header("User-Agent", "Mozilla/5.0").build();
        return HTTP.sendAsync(rq, HttpResponse.BodyHandlers.ofString()).thenApply(r -> {
            JsonArray arr = JsonParser.parseString(r.body()).getAsJsonArray().get(0).getAsJsonArray();
            StringBuilder sb = new StringBuilder();
            for (var e : arr) sb.append(e.getAsJsonArray().get(0).getAsString());
            return sb.toString();
        });
    }

    static void incoming(Text msg) {
        if (!Config.I.chatIn) return;
        String s = msg.getString();
        if (s.length() < 4 || s.startsWith("[Dịch]") || VI.matcher(s).find() || !s.matches(".*[A-Za-z]{3,}.*")) return;
        translate(s, "vi").thenAccept(tr -> {
            if (tr == null || tr.isBlank() || tr.equalsIgnoreCase(s)) return;
            MinecraftClient mc = MinecraftClient.getInstance();
            mc.execute(() -> mc.inGameHud.getChatHud().addMessage(Text.literal("§7[Dịch] §f" + tr)));
        }).exceptionally(ex -> null);
    }

    public static void init() {
        ClientReceiveMessageEvents.GAME.register((msg, overlay) -> { if (!overlay) incoming(msg); });
        ClientReceiveMessageEvents.CHAT.register((msg, signed, sender, params, ts) -> incoming(msg));
        ClientSendMessageEvents.ALLOW_CHAT.register(msg -> {
            if (bypass || !Config.I.chatOut || !VI.matcher(msg).find()) return true;
            translate(msg, "en").thenAccept(en -> {
                MinecraftClient mc = MinecraftClient.getInstance();
                mc.execute(() -> { if (mc.player != null) { bypass = true; mc.player.networkHandler.sendChatMessage(en == null || en.isBlank() ? msg : en); bypass = false; } });
            }).exceptionally(ex -> {
                MinecraftClient mc = MinecraftClient.getInstance();
                mc.execute(() -> { if (mc.player != null) { bypass = true; mc.player.networkHandler.sendChatMessage(msg); bypass = false; } });
                return null;
            });
            return false;
        });
    }
}
