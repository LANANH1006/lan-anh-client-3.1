package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

/** Cosmetic portal particles when the local player makes a large position discontinuity. */
public final class TeleportTrail {
    private TeleportTrail() {}
    private static Vec3d last;
    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) { last=null; return; }
        Vec3d now=mc.player.getPos();
        if (last != null && Config.I.enabled && Config.I.teleportTrail && now.squaredDistanceTo(last) > 64.0) {
            for (int i=0;i<18;i++) {
                double t=i/17.0;
                double x=last.x+(now.x-last.x)*t, y=last.y+(now.y-last.y)*t+0.6, z=last.z+(now.z-last.z)*t;
                mc.world.addParticle(ParticleTypes.PORTAL,x,y,z,0,0.03,0);
            }
        }
        last=now;
    }
}
