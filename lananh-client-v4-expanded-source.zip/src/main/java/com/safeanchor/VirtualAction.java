package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** One-key utility macro for a configurable action behind the player. No packet spoofing. */
public final class VirtualAction {
    private VirtualAction() {}
    private static int cooldown;

    public static void trigger(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        Config c = Config.I;
        if (!c.enabled || !c.virtualOn) { Util.warn("Virtual đang tắt trong menu"); return; }
        if (cooldown > 0) return;
        cooldown = Math.max(1, c.virtualDelay);
        var p = mc.player;
        // Minecraft yaw: derive a block directly behind the player.
        double yaw = Math.toRadians(p.getYaw());
        int bx = (int)Math.floor(p.getX() + Math.sin(yaw));
        int bz = (int)Math.floor(p.getZ() - Math.cos(yaw));
        BlockPos behind = new BlockPos(bx, p.getBlockY(), bz);
        switch (Math.floorMod(c.virtualPreset, 4)) {
            case 0 -> {
                if (!Util.selectItem(st -> st.isOf(Items.OBSIDIAN))) { Util.warn("Virtual: thiếu Obsidian"); return; }
                if (!mc.world.getBlockState(behind).isReplaceable()) behind = behind.up();
                if (!Util.placeBlock(behind, Items.OBSIDIAN)) Util.warn("Virtual: không đặt được Obsidian phía sau");
            }
            case 1 -> {
                if (!Util.selectItem(st -> st.isOf(Items.RESPAWN_ANCHOR))) { Util.warn("Virtual: thiếu Anchor"); return; }
                if (!mc.world.getBlockState(behind).isReplaceable()) behind = behind.up();
                if (!Util.placeBlock(behind, Items.RESPAWN_ANCHOR)) Util.warn("Virtual: không đặt được Anchor phía sau");
            }
            case 2 -> {
                // Crystal setup: place obsidian only, then select crystal for the player's next action.
                if (!Util.selectItem(st -> st.isOf(Items.OBSIDIAN))) { Util.warn("Virtual: thiếu Obsidian"); return; }
                if (!mc.world.getBlockState(behind).isReplaceable()) behind = behind.up();
                if (Util.placeBlock(behind, Items.OBSIDIAN)) Util.selectItem(st -> st.isOf(Items.END_CRYSTAL));
            }
            case 3 -> {
                if (!Util.selectItem(st -> st.isOf(Items.TOTEM_OF_UNDYING))) Util.warn("Virtual: thiếu Totem");
            }
        }
    }

    public static void tick() { if (cooldown > 0) cooldown--; }
}
