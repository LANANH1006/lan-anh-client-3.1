package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;

/** Optional, edge-triggered key click sounds. */
public final class KeySounds {
    private KeySounds() {}
    private static boolean f,b,l,r,j,s,attack,use;
    private static void play(MinecraftClient mc, float pitch) {
        if (mc.player != null && mc.world != null) mc.player.playSound(SoundEvents.UI_BUTTON_CLICK.value(), Config.I.keySoundVolume, pitch);
    }
    public static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.currentScreen != null || !Config.I.enabled || !Config.I.keySounds) { reset(); return; }
        boolean nf=mc.options.forwardKey.isPressed(), nb=mc.options.backKey.isPressed(), nl=mc.options.leftKey.isPressed(), nr=mc.options.rightKey.isPressed();
        boolean nj=mc.options.jumpKey.isPressed(), ns=mc.options.sneakKey.isPressed(), na=mc.options.attackKey.isPressed(), nu=mc.options.useKey.isPressed();
        if(nf&&!f)play(mc,1.15f); else if(nb&&!b)play(mc,0.85f); else if((nl&&!l)||(nr&&!r))play(mc,1.0f);
        if(nj&&!j)play(mc,1.25f); if(ns&&!s)play(mc,0.75f); if(na&&!attack)play(mc,1.35f); if(nu&&!use)play(mc,0.95f);
        f=nf;b=nb;l=nl;r=nr;j=nj;s=ns;attack=na;use=nu;
    }
    private static void reset(){f=b=l=r=j=s=attack=use=false;}
}
