# LAN ANH CLIENT v4 — update source notes

Minecraft Java 1.21.4 / Fabric / Java 21.

## Included in this source update
- AutoMine: optional automatic tool selection; tree-finish mode adds log-tagged blocks as secondary targets; rebuilds targets when the tree-finish option changes.
- Radar: retains the existing 2D player/block radar, heading rotation, and Y difference labels.
- Virtual action (O): configurable rear action presets: place obsidian, place respawn anchor, place obsidian then select end crystal, or select totem. This is a client-side convenience macro and remains subject to normal reach, inventory, and server rules.
- Key click sounds: optional edge-triggered movement/jump/sneak/attack/use sounds with adjustable volume.
- Teleport trail: optional portal-particle trail when the local player position changes abruptly (visual only; does not alter teleport movement).
- Mace height gate: optional auto-hit condition when the local player's feet are approximately level with the target's head.
- Removed Spin Bot entry from the visible PvP menu. The old class remains in source for compatibility but is no longer exposed from that menu.

## Important limitations
- This is source code, not a tested release JAR. Build with the included GitHub Actions workflow or `gradle build` on Java 21.
- Virtual action is not a full arbitrary scripting editor: it currently offers four presets.
- Radar cannot reveal unloaded chunks or entities/blocks the client has not received from the server.
- AutoMine is a lightweight in-client pathing routine, not the full Baritone project; test in a disposable world before using it on a server.
